DROP TABLE IF EXISTS Store;
DROP TABLE IF EXISTS Product;
DROP TABLE IF EXISTS Vendor;
DROP TABLE IF EXISTS Supply;
DROP TABLE IF EXISTS Inventory;
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS SalesTransaction;
DROP TABLE IF EXISTS Transaction_item;


CREATE TABLE Store (
store_id INT PRIMARY KEY,
name VARCHAR(200) NOT NULL ,
address VARCHAR(300) ,
hours VARCHAR(100) ,
ownership_type ENUM('Franchise', 'Personal') NOT NULL
);

CREATE TABLE Product (
	UPC CHAR(15) PRIMARY KEY,
    brand VARCHAR(100),
    packaging VARCHAR(100),
    size VARCHAR(50),
    price DECIMAL(20,2) CHECK(price >=0)
    );
    
    CREATE TABLE Vendor(
    vendor_id INT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    contact VARCHAR(200)
    );
    
    CREATE TABLE Supply(
    vendor_id INT,
    UPC CHAR(15),
    PRIMARY KEY (vendor_id,UPC),
    FOREIGN KEY (vendor_id) REFERENCES Vendor(vendor_id) ON DELETE CASCADE,
    FOREIGN KEY (UPC) REFERENCES Product(UPC) ON DELETE CASCADE 
    );
    
    CREATE TABLE Inventory (
    store_id INT,
    UPC CHAR(15),
    quantity INT NOT NULL CHECK(quantity>=0),
    reorder_level INT DEFAULT 10 CHECK(reorder_level>=0),
    last_order_date DATE,
    is_reorder_pending BOOLEAN DEFAULT FALSE,
    PRIMARY KEY(store_id,UPC),
    FOREIGN KEY (store_id) REFERENCES Store(store_id) ON DELETE CASCADE,
    FOREIGN KEY (UPC) REFERENCES Product(UPC) ON DELETE CASCADE
);

	CREATE TABLE Customer(
	customer_id INT PRIMARY KEY,
    name VARCHAR(200),
    phone VARCHAR(50),
    email VARCHAR(100),
    is_loyal BOOLEAN DEFAULT FALSE
    );
    
    CREATE TABLE SalesTransaction(
    transaction_id INT PRIMARY KEY,
    store_id INT,
    customer_id INT,
    date_time DATETIME NOT NULL,
    payment_type ENUM('Card','Cash') NOT NULL,
    total_amount DECIMAL(10,2),
    FOREIGN KEY (store_id) REFERENCES Store(store_id) ON DELETE SET NULL,
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id) ON DELETE SET NULL
    );

	CREATE TABLE Transaction_item(
    transaction_id INT,
    UPC CHAR(15),
	quantity INT NOT NULL CHECK(quantity>0),
    PRIMARY KEY (transaction_id,UPC),
    FOREIGN KEY (transaction_id) REFERENCES SalesTransaction(transaction_id) ON DELETE CASCADE,
    FOREIGN KEY (UPC) REFERENCES Product(UPC) ON DELETE CASCADE
);
    
    
    

