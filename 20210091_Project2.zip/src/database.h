#ifndef DB_QUERIES_H
#define DB_QUERIES_H

#include <mysql.h>
#include <string>

void connectDB();
void executeQuery(const std::string &query, const std::string *headers, int columnCount);

void TYPE1();
void TYPE2();
void TYPE3();
void TYPE4();
void TYPE5();
void TYPE6();
void TYPE7();

void showMenu();

extern MYSQL *conn;

#endif // DB_QUERIES_H