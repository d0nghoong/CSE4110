#include <iostream>
#include <mysql.h>
#include <string>
#include "database.h"

using namespace std;

    MYSQL *conn;
    MYSQL_RES *res;
    MYSQL_ROW row;

void connectDB(){
    const char *server = "localhost";
    const char *user = "root";
    const char *password = "Birdbird1@"; // 여기에 비밀번호 입력
    const char *database = "convenience_store"; 
    

    conn=mysql_init(nullptr);
    if(conn==nullptr){
        std::cerr<<"mysql_init() failed\n";
        return ;
    }

// 1) Create a local variable whose value is SSL_MODE_DISABLED

mysql_ssl_mode sslmode = SSL_MODE_DISABLED;

 

// 2) Pass its address to mysql_options()

if (mysql_options(conn, MYSQL_OPT_SSL_MODE, &sslmode)) {

// mysql_options() returns nonzero on error

std::cerr << "mysql_options() failed: " << mysql_error(conn) << "\\n";

mysql_close(conn);

return ;

}
        if (mysql_real_connect(conn, server, user, password, database, 0, nullptr, 0) == nullptr) {
        std::cerr << "mysql_real_connect() failed: " << mysql_error(conn) << endl;
        mysql_close(conn);
        return ;
    }
}

void executeQuery(const string &query, const string *headers, int columnCount){
       if (mysql_query(conn, query.c_str())) {
        std::cerr << "Query failed: " << mysql_error(conn) << endl;
        return;
    }

    res = mysql_store_result(conn);
    if (res == nullptr) {
        std::cerr << "mysql_store_result() failed: " << mysql_error(conn) << endl;
        return;
    }

     for (int i = 0; i < columnCount; i++) {
        cout << headers[i] << "\t";
    }
    cout << "\n-----------------------------------------\n";

    while ((row = mysql_fetch_row(res))) {
        for (int i = 0; i < columnCount; i++) {
            cout << (row[i] ? row[i] : "NULL") << "\t";
        }
        cout << "\n";
    }

    mysql_free_result(res);
}

void TYPE1(){
    string upc;
    cout<< "Enter Product UPC: ";
    cin>> upc;
    
    string sql = " SELECT s.store_id, s.name, i.quantity FROM Inventory i "
             " JOIN Store s ON i.store_id = s.store_id "
             " WHERE i.UPC = '" + upc + "';";
    
    const string headers[]={"Store ID", "Store Name", "Quantity"};
    executeQuery(sql, headers, 3);
}

void TYPE2(){
       string sql = " SELECT p.UPC, p.brand, p.packaging, SUM(ti.quantity) AS total_sold "
                 " FROM Transaction_item ti JOIN Product p ON ti.UPC = p.UPC "
                 " GROUP BY p.UPC ORDER BY total_sold DESC LIMIT 5;";
    const string headers[] = {"UPC", "Brand", "Packaging", "Total Sold"};
    executeQuery(sql, headers, 4);
}

void TYPE3(){
    string sql = " SELECT s.store_id, s.name, SUM(st.total_amount) AS total_sales "
                 " FROM SalesTransaction st JOIN Store s ON st.store_id = s.store_id "
                 " GROUP BY s.store_id ORDER BY total_sales DESC;";
    const string headers[] = {"Store ID", "Store Name", "Total Sales"};
    executeQuery(sql, headers, 3);

}

void TYPE4(){
    string sql = " SELECT v.vendor_id, v.name, SUM(ti.quantity) AS total_sold "
                 " FROM Vendor v "
                 " JOIN Supply sp ON v.vendor_id = sp.vendor_id "
                 " JOIN Transaction_item ti ON sp.UPC = ti.UPC "
                 " GROUP BY v.vendor_id "
                 " ORDER BY total_sold DESC;";
    const string headers[] = {"Vendor ID", "Vendor Name", "Total Sales"};
    executeQuery(sql, headers, 3);

}

void TYPE5(){
    string sql = " SELECT s.name AS store_name, p.brand AS product, i.quantity, i.reorder_level "
                 " FROM Inventory i JOIN Store s ON i.store_id = s.store_id "
                 " JOIN Product p ON i.UPC = p.UPC "
                 " WHERE i.quantity < i.reorder_level;";
    const string headers[] = {"Store Name", "Product", "Quantity", "Reorder Level"};
    executeQuery(sql, headers, 4);

}

void TYPE6() {
    string sql = " SELECT p.UPC, p.brand, SUM(ti.quantity) AS total_bought "
                 " FROM Customer c JOIN SalesTransaction st ON c.customer_id = st.customer_id "
                 " JOIN Transaction_item ti ON st.transaction_id = ti.transaction_id "
                 " JOIN Product p ON ti.UPC = p.UPC "
                 " WHERE c.is_loyal = TRUE "
                 " GROUP BY p.UPC ORDER BY total_bought DESC LIMIT 3;";
    const string headers[] = {"UPC", "Brand", "Total Bought"};
    executeQuery(sql, headers, 3);
}

void TYPE7() {
    string sql = " SELECT s.ownership_type, COUNT(DISTINCT i.UPC) AS product_variety "
                 " FROM Inventory i JOIN Store s ON i.store_id = s.store_id "
                 " GROUP BY s.ownership_type;";
    const string headers[] = {"Ownership Type", "Product Variety"};
    executeQuery(sql, headers, 2);
}

void showMenu(){
    cout<< "\n=== Select Query Types ===\n";
    cout<<"1.TYPE 1"<<"\n";    
    cout<<"2.TYPE 2"<<"\n";
    cout<<"3.TYPE 3"<<"\n";
    cout<<"4.TYPE 4"<<"\n";
    cout<<"5.TYPE 5"<<"\n";
    cout<<"6.TYPE 6"<<"\n";
    cout<<"7.TYPE 7"<<"\n";
}

int main(){
    connectDB();

    int choice;
    do{
        showMenu();
        cin>>choice;

        switch(choice){
            case 1: TYPE1(); break;
            case 2:TYPE2(); break;
            case 3:TYPE3(); break;
            case 4:TYPE4(); break;
            case 5:TYPE5(); break;
            case 6:TYPE6(); break;
            case 7:TYPE7(); break;
            case 0: cout << "Exiting\n";
        }

    }while(choice!=0);
    
    mysql_close(conn);
    return 0;
}


