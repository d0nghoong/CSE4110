## 개요

`main.cpp`는 MySQL C API를 사용하여 편의점 유통 데이터베이스에 연결하고, 쿼리를 실행합니다.

## ⚙️ 실행 환경

- **실행 환경**: Windows MinGW
- **DB**: MySQL 8.0

## 컴파일 방법

ctrl+ shift+ b

## ▶실행 방법

./main.exe

## DB 접속 정보 설정

`connectDB()`에서서 본인의 환경에 맞게 정보를 입력한다:

const char *server = "localhost";
const char *user = "root";
const char *password = "YourPassword";
const char *database = "convenience_store";

## 지원 쿼리 목록

프로그램은 아래의 7개 쿼리를 지원한다

1. 특정 제품의 매장별 재고 조회 -> `TYPE1()`
2. 전체 제품 중 판매량 상위 5개 조회 -> `TYPE2()`
3. 매장별 총 매출 조회 -> `TYPE3()`
4. 공급자별 판매 제품 총량 조회 -> `TYPE4()`
5. 재고가 임계치 이하인 항목 목록 -> `TYPE5()`
6. 로열티 고객들이 가장 많이 구매한 제품 Top3 -> `TYPE6()`
7. 프랜차이즈 vs 직영점 상품 다양성 비교 -> `TYPE7()`

## 프로그램 실행

프로그램 실행 시 아래와 같은 메뉴가 출력되며, 번호를 입력하면 원하는 쿼리를 실행된다.

=== Select Query Types ===
1.TYPE 1
2.TYPE 2
3.TYPE 3
4.TYPE 4
5.TYPE 5
6.TYPE 6
7.TYPE 7

## 예외 처리 및 주의 사항

- SSL 인증 비활성화를 위해 `mysql_options()`에 `SSL_MODE_DISABLED`를 명시한다.
- 연결 실패 시 오류 메시지가 출력된다.
